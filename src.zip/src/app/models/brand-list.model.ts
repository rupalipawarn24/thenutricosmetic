export class BrandList {
    id?: any;
    name?: string;
    shop_name?: string;
}
export class addReview {

product_id:number
customer_id:number
variant_id:number
ratings:number
customer_name:string
customer_email:string
comment_title:string
comment:string
}
export class getReview {

    product_id:number
    
    }