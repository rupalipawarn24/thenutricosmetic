import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-promise',
  templateUrl: './customer-promise.component.html',
  styleUrls: ['./customer-promise.component.css']
})
export class CustomerPromiseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
