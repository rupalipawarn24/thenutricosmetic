import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gift-cards-faq',
  templateUrl: './gift-cards-faq.component.html',
  styleUrls: ['./gift-cards-faq.component.css']
})
export class GiftCardsFaqComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
