import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-covid-information',
  templateUrl: './covid-information.component.html',
  styleUrls: ['./covid-information.component.css']
})
export class COVIDInformationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
