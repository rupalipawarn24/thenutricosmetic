import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-return-exchanges',
  templateUrl: './return-exchanges.component.html',
  styleUrls: ['./return-exchanges.component.css']
})
export class ReturnExchangesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
