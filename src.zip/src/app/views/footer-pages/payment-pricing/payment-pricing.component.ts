import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-pricing',
  templateUrl: './payment-pricing.component.html',
  styleUrls: ['./payment-pricing.component.css']
})
export class PaymentPricingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
