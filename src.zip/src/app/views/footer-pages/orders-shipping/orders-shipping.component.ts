import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orders-shipping',
  templateUrl: './orders-shipping.component.html',
  styleUrls: ['./orders-shipping.component.css']
})
export class OrdersShippingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
