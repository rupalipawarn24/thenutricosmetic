import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-affiliates-faqs',
  templateUrl: './affiliates-faqs.component.html',
  styleUrls: ['./affiliates-faqs.component.css']
})
export class AffiliatesFaqsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
