import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-how-to-shop',
  templateUrl: './how-to-shop.component.html',
  styleUrls: ['./how-to-shop.component.css']
})
export class HowToShopComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
  }

}
