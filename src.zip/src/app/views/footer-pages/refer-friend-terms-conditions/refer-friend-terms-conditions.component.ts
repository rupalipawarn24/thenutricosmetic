import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-refer-friend-terms-conditions',
  templateUrl: './refer-friend-terms-conditions.component.html',
  styleUrls: ['./refer-friend-terms-conditions.component.css']
})
export class ReferFriendTermsConditionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
