import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-beauty-beneath-the-surface',
  templateUrl: './beauty-beneath-the-surface.component.html',
  styleUrls: ['./beauty-beneath-the-surface.component.css']
})
export class BeautyBeneathTheSurfaceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
