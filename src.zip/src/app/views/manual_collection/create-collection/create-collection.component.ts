import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-collection',
  templateUrl: './create-collection.component.html',
  styleUrls: ['./create-collection.component.css']
})
export class CreateCollectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
