import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-collections',
  templateUrl: './show-collections.component.html',
  styleUrls: ['./show-collections.component.css']
})
export class ShowCollectionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
